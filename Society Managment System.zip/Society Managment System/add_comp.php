<?php
	require 'connect.php';
	require 'session.php';

	if(ISSET($_POST['save_comp'])){
			$username = $_POST['username'];
			$issue_date = $_POST['issue_date'];
			$issue_desc = $_POST['issue_desc'];

			
			
			$con->query("INSERT INTO issues VALUES(NULL, '$username', '$issue_date', '$issue_desc', 'incomplete', '$content')") or die(mysqli_error($con));
			header("location:complain.php");	
			if(!mysqli_query($con,$sql)) 
			{
			    die('Error: ' . mysqli_error($con));
			}

			else
			{

			    echo '<script language="javascript">';
			    echo 'alert("Successfully complain added"); location.href="complain.php"';
			    echo '</script>';
			}
			$con->query("UPDATE `flat` SET `status`='1' where `flat_id`='$flat_id' ") or die(mysqli_error($con));
			$fquery = $con->query("SELECT * FROM account WHERE username = $username") or die(mysqli_error($con));
			$f_fetch = $fquery->fetch_array();
			$e_mail = $f_fetch['e-mail'];
			$mail = new PHPMailer;
			$mail->IsSMTP();
			$mail->Mailer = "smtp";
			$mail->SMTPDebug  = 0;  
			$mail->SMTPAuth   = TRUE;
			$mail->SMTPSecure = "tls";
			$mail->Port       = 587;
			$mail->Host       = "smtp.gmail.com";
			$mail->Username   = "kartikenrawat13@gmail.com";
			$mail->Password   = "kartiken@1234";
			$mail->IsHTML(true);
			$mail->AddAddress($e_mail, $username);
			$mail->SetFrom("kartikenrawat13@gmail.com", "admin");
			$mail->AddReplyTo("kartikenrawat13@gmail.com", "kartiken");

			$mail->Subject = "We are waiting for your Payment";
			$content = "<b> DEAR,".$fullname." ,</b><br/> <p>We are contacting you in regard to a new bill that has been created on your account. You may find the bill attached. Please pay your bill <br/>
				We look forward to conducting future business with you.<br/>
				Kind Regards,
				admin
				Metropolish city</p>";
			$mail->MsgHTML($content); 
			if(!$mail->Send()) {
			  echo "Error while sending Email.";
			  var_dump($mail);
			} else {
			  echo "Email sent successfully";
			}	

	}	
?>