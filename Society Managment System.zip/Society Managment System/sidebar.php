
<?php 
	require'connect.php';
?>

<div id = "sidebar">
	<ul id = "menu" class = "nav menu">
		
			<a>
				<?php 
					require_once 'connect.php';
					$q_admin_side = $con->query("SELECT * FROM `account` WHERE `username` = '$_SESSION[username]'") or die(mysqli_error());
					$f_admin_side = $q_admin_side->fetch_array();
					echo "<center>".$f_admin_side['fullname']."</center>";
				?>
			</a>
		
		<a href = "home.php">&nbsp&nbsp&nbsp&nbsp<span class = "glyphicon glyphicon-home"></span>&nbsp&nbsp Home &nbsp&nbsp&nbsp</a>
		<a href = "complain.php"><span class = "glyphicon glyphicon-tasks"></span> Complains &nbsp&nbsp&nbsp</a>
		<a href = "mybill.php"><span class = "glyphicon glyphicon-tasks"></span> My Bill &nbsp&nbsp&nbsp	
		</a>
		
		<a href = "profile.php"><span class = "glyphicon glyphicon-tasks"></span> My profile &nbsp&nbsp&nbsp	
		</a>
		
		<a href = "contact us.php"><span class = "glyphicon glyphicon-phone">Contact &nbsp&nbsp&nbsp</a>
		<a href = "logout.php" style="float:right;"><span class = "glyphicon glyphicon-log-out">Logout&nbsp&nbsp&nbsp</a>
	</ul>
</div>