<?php
	require 'connect.php';
	if(ISSET($_POST['save_bill'])){
			$flat_id = $_POST['flat_id'];
			$bill_date = $_POST['bill_date'];
			$water_charges = $_POST['water_charges'];
			$parking_charges = $_POST['parking_charges'];
			$tax = $_POST['tax'];
			$due_date = $_POST['due_date'];
			$rs = $tax/100;
			$sum = $water_charges + $parking_charges;
			$total_tax = $sum*$rs;
			$grand_total = $sum + $total_tax;
			
			$sql = "INSERT INTO bill VALUES(NULL, '$flat_id', '$bill_date', '$water_charges','$parking_charges', '$tax', '$due_date', '$grand_total')";
			if(!mysqli_query($con,$sql)) 
			{
			    die('Error: ' . mysqli_error($con));
			}

			else
			{

			    echo '<script language="javascript">';
			    echo 'alert("Successfully BILL ADDED"); location.href="maintenance.php"';
			    echo '</script>';
			}
			//adding to notice of user//
			$con->query("INSERT INTO alert VALUES(NULL, '$flat_id', 'you got bill!', '0')") or die(mysqli_error($con));
	}
?>