<nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid">
		<a class="navbar-brand" href="#">
			<img src="../image/logo1.png" width="30" height="30" alt="">
		</a>
		<a class = "navbar-brand">Society Management System</a>
	<div>
</nav>