<!DOCTYPE html>
<html>
<head>
	<title>LOGIN FORM</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css"/ >
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/ >
</head>
<body>	
	<div class="container">
		<div class="login-box">
		<div class="row">
		<div class="col-md-6 login-block">
			<div id="h2">
				<h2>Admin Login</h2>
			</div>
			<form action="validation.php" method="post">
				<div class="form-group">
					<input type="text" name="username" class="form-control" placeholder="Enter the User Name"/ >
				</div>	
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="password"/ >
				</div>
				<button type="submit" class="btn btn-primary">Login</button>
			</form>
		</div>	
		</div>
	</div>	
</div>
</body>
</html>