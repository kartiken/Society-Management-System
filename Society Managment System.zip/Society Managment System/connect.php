<?php
	$con = new mysqli('localhost', 'root', '', 'society') or die(mysqli_error());
?>